/* global QUnit */

sap.ui.require(["sapa/demo/basodatacust/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
