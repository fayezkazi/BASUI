sap.ui.define([
	"sapademo/basodatacust/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
